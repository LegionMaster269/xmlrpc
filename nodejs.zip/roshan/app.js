const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');

class AuthApp {
  constructor() {
    this.app = express();
    this.db = this.connectToDatabase();
    this.configureMiddleware();
    this.setRoutes();
    this.startServer();
  }

  connectToDatabase() {
    const db = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'roshan'
    });

    db.connect(err => {
      if (err) throw err;
      console.log('Database connected.');
    });

    return db;
  }

  configureMiddleware() {
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'views'));
    this.app.use(express.static('public'));
    this.app.use(bodyParser.urlencoded({ extended: true }));

    this.app.use(session({
      secret: 'secret_key',
      resave: false,
      saveUninitialized: true
    }));
  }

  setRoutes() {
    this.app.get('/login', (req, res) => this.showLogin(req, res));
    this.app.post('/login', (req, res) => this.login(req, res));
    this.app.get('/admin', (req, res) => this.admin(req, res));
    this.app.get('/logout', (req, res) => this.logout(req, res));
  }

  sanitize(str) {
    return str.replace(/[<>]/g, '');
  }

  showLogin(req, res) {
    res.render('login', { error: null });
  }

  login(req, res) {
    const user = this.sanitize(req.body.user);
    const pass = this.sanitize(req.body.pass);

    const sql = 'SELECT * FROM tblusers WHERE user = ? AND pass = ?';
    this.db.query(sql, [user, pass], (err, results) => {
      if (err) throw err;

      if (results.length > 0) {
        req.session.user = user;
        res.redirect('/admin');
      } else {
        res.render('login', { error: 'Invalid username or password' });
      }
    });
  }

  admin(req, res) {
    if (req.session.user) {
      res.send(`Welcome ${req.session.user}, you are logged in. <a href="/logout">Logout</a>`);
    } else {
      res.redirect('/login');
    }
  }

  logout(req, res) {
    req.session.destroy();
    res.redirect('/login');
  }

  startServer() {
    this.app.listen(3000, () => {
      console.log('Server running on http://localhost:3000');
    });
  }
}

// Start the app
new AuthApp();
